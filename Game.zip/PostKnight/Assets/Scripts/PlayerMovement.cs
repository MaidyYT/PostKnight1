using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;


public class PlayerMovement : MonoBehaviour
{
    public Rigidbody2D rb;
    public Animator anim;

    public bool doWalk = true;

    [SerializeField] float speed;
    [SerializeField] float jumpForce;

    [SerializeField] bool isClickedAttackButton = false;
    [SerializeField] bool isClickedShieldButton = false;

    private float swordAttackCooldown;

    public Collider2D enemyCheck;
    

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.D))
            doWalk = true;
        if (Input.GetKeyDown(KeyCode.A))
            doWalk = false;
        if (doWalk)
        {
            rb.velocity = new Vector2(speed, 0);
            anim.SetBool("PlayerWalk", true);
        }
        else
        {
            anim.SetBool("PlayerWalk", false);
        }



        if(Input.GetKeyDown(KeyCode.F))
        {
            doWalk = false;
            anim.SetBool("PlayerAttack", true);
        }
        else
        {
            anim.SetBool("PlayerAttack", false);
        }
        


        if (Input.GetKeyDown(KeyCode.G))
        {
            doWalk = true;
            anim.SetBool("PlayerAttack", false);
        }
    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(enemyCheck.CompareTag("PlayerRadius") && collision.CompareTag("Enemy"))
        {
            doWalk = false;
            anim.SetBool("PlayerIdle", true);
        }       
    }

    public void OnAttackButtonCkicked()
    {
        isClickedAttackButton = true;
        anim.SetBool("PlayerAttack", true);
    }
}
