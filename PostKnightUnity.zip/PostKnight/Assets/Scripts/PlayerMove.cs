﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {

    public Rigidbody2D rb;
    public Animator anim;

    private bool DoWalk = true;

    private Transform PlayerPosition;
	void Start () {

        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
	}
	void Update () {
		if(DoWalk)
        {
            PlayerPosition.transform.position = new Vector2(3f, 0)* Time.deltaTime;
            anim.SetInteger("idle", 0);
            anim.SetInteger("walk", 1);
        }
        else
        {
            anim.SetInteger("walk", 0);
            anim.SetInteger("idle", 1);
        }
	}
}
